from distutils.core import setup

setup(
    name='biostuff',
    version='0.1dev',
    author='Fulya Taylan',
    author_email='fulyataylan@gmail.com',
    url='example.com',
    packages=['biostuff',],
    license='GPLv3',
    long_description=open('README.txt').read(),
)
